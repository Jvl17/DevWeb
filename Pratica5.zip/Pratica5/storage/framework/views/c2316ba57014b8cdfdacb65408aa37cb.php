<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">
    <title>Adicionar Palavras</title>
</head>
<body>
    <h1>Adicionar Nova Palavra</h1>
    <form method="POST" action="/dicionarios/store">
        <?php echo csrf_field(); ?>
        <label for="palavra"> Palavra: </label>
        <input type="text" id="palavra" name="palavra" required>
        <br>
        <label for="significado"> Significado: </label>
        <textarea name="significado" id="significado"  required></textarea>
        <br>
        <button type="submit">Adicionar</button>
    </form>
</body>
</html><?php /**PATH C:\Users\12202630\Documents\projeto-modelo\resources\views/dicionarios/create.blade.php ENDPATH**/ ?>