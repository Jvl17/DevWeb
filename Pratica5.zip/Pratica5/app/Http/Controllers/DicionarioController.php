<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dicionario;


class DicionarioController extends Controller
{
    public function index()
    {
        $dicionarios = Dicionario::all();
        return view('dicionarios.index', compact('dicionarios'));
    }

    public function create()
    {
        return view ('dicionarios.create');
    }

    public function store(Request $request)
    {
        $request -> validate([
            'palavra' => 'required|string|max:255',
            'significado' => 'required|string',
        ]);

        Dicionario::create($request->only('palavra', 'significado'));

        return redirect('/dicionarios');


    }
}
