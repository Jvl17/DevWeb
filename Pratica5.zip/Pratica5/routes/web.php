<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DicionarioController;


Route::get('/dicionarios', [DicionarioController::class, 'index']);
Route::get('/dicionarios/create', [DicionarioController::class, 'create']);
Route::post('/dicionarios/store', [DicionarioController::class, 'store']);