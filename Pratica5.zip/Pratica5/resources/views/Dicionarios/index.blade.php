<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/styles.css') }}">
    <title>Dicionario</title>
</head>
<body>
    
    <h1>Lista de Palavras</h1>
    <a href="/dicionarios/create">Adicionar nova Palavra</a>
    <ul>
        @foreach ($dicionarios as $dicionario)
            <li><strong>{{ $dicionario->palavra }}</strong> {{ $dicionario->significado }}</li>
        @endforeach
    </ul>

</body>
</html>